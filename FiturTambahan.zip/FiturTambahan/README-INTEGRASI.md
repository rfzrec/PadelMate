PADELMATE - PAKET FITUR KALENDER & MAP
======================================

ISI PAKET
- frontend/booking.html
- frontend/js/booking.js
- frontend/css/style.css
- services/booking-service/server.js

CARA MENGGUNAKAN FITUR KALENDER
1. Ekstrak PadelMate_Base_Tanpa_Kalender_Map.zip.
2. Salin file-file pada folder patch ini ke folder proyek dengan path yang sama,
   lalu izinkan penggantian file.
3. Jalankan: docker compose up --build -d
4. Periksa container: docker compose ps
5. Uji halaman booking dan ketersediaan slot.

CATATAN PENTING TENTANG MAP
Source ZIP yang diunggah tidak berisi halaman, script, endpoint, library peta,
atau field koordinat/alamat lapangan untuk fitur Map. Skema tabel courts hanya
memiliki id, name, type, price_per_hour, status, dan created_at. Karena itu,
paket ini hanya dapat memulihkan implementasi Kalender yang memang ditemukan
di source. Fitur Map tidak dibuat-buat atau diklaim sudah tersedia.

Agar Map bisa ditambahkan dengan benar, tentukan alamat/latitude/longitude tiap
lapangan dan mekanisme penyimpanannya terlebih dahulu. Setelah itu fitur Map
bisa dikembangkan sebagai perubahan terpisah dan dimasukkan ke pipeline CI/CD.

CI/CD
Paket ini bukan workflow CI/CD itu sendiri. Setelah menggabungkan perubahan,
buat workflow GitHub Actions untuk build dan test; deployment otomatis harus
dikonfigurasi sesuai target hosting. Jangan memasukkan file .env atau rahasia
ke repository.
